package com.rest.dao;

import java.util.List;

import com.rest.model.Employee;

public interface EmployeeDao {
	
	Employee getEmployeeById(long id);

	boolean saveEmployee(Employee emp);

	boolean updateEmployee(Employee emp);

	List<Employee> findAllEmployees();

}
