package com.rest.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.rest.model.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {
	
	@Autowired  
	 private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	public void setNamedParameterJdbcTemplate(
			NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
	}

	public Employee getEmployeeById(long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Transactional
	public boolean saveEmployee(Employee emp) {
		Map<String, Object> params = new HashMap<String, Object>();

		String query = "INSERT INTO employee (id, first_name, last_name, email, phone) "
						+ "VALUES (:empId, :firstName, :lastName, :email, :phone)";
		
		params.put("empId", emp.getEmpId());
		params.put("firstName", emp.getFirstName());
		params.put("lastName", emp.getLastName());
		params.put("email", emp.getEmail());
		params.put("phone", emp.getPhone());
		
	    namedParameterJdbcTemplate.update(query, params);

		return true;
	}

	public boolean updateEmployee(Employee emp) {
		return false;

	}

	public List<Employee> findAllEmployees() {
		String SQL = "select id as empId, first_name as firstName, last_name as lastName, email as email, "
				+ "phone as phone from EMPLOYEE";
		List<Employee> employeeList=
				namedParameterJdbcTemplate.query(SQL, new BeanPropertyRowMapper<Employee>(Employee.class));
		return employeeList;
	}

}
