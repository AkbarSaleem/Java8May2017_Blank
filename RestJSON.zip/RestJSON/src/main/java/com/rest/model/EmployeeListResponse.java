package com.rest.model;

public class EmployeeListResponse {

}
