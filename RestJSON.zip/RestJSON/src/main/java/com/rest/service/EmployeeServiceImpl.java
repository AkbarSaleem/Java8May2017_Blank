package com.rest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rest.dao.EmployeeDao;
import com.rest.model.CreateEmployee;
import com.rest.model.Employee;

@Service("employeeService")
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeDao employeeDao;

	public Employee getEmployeeById(long id) {
		return null;
	}

	public CreateEmployee saveEmployee(Employee emp) {
		CreateEmployee response=new CreateEmployee();
		boolean isResponse = employeeDao.saveEmployee(emp);
		if(isResponse){
			response.setStatus(true);
			response.setMessage("New Employee created successful.");
		}
		else{
			response.setStatus(false);
			response.setMessage("New Employee not created.");
		}
		return response;
	}

	public void updateEmployee(Employee emp) {

	}
	
	public List<Employee> findAllEmployees() {
		return employeeDao.findAllEmployees();
	}

	public boolean isUserExist(Employee emp) {
		return false;
	}

}
