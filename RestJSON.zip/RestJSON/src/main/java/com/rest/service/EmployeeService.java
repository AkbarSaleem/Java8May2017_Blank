package com.rest.service;

import java.util.List;

import com.rest.model.CreateEmployee;
import com.rest.model.Employee;

public interface EmployeeService {

	Employee getEmployeeById(long id);

	CreateEmployee saveEmployee(Employee emp);

	void updateEmployee(Employee emp);

	List<Employee> findAllEmployees();

	// void deleteEmployeeById(long id);

	// void deleteAllEmployees();

	public boolean isUserExist(Employee emp);

}
