package com.rest.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rest.model.AppConstants;
import com.rest.model.CreateEmployee;
import com.rest.model.Employee;
import com.rest.service.EmployeeService;

@Controller
public class EmployeeController {
	
	@Autowired
	private EmployeeService employeeService;
	
	private static final Logger logger = LoggerFactory.getLogger(EmployeeController.class);

	Map<Integer, Object> empData = new HashMap<Integer, Object>();

	@RequestMapping(value = AppConstants.DUMMY_EMP, method = RequestMethod.GET,
							consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE},
							produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	public @ResponseBody Employee getDummyEmployee() {
		logger.info("Start getDummyEmployee");
		Employee emp = new Employee();
		emp.setEmpId(9999);
		emp.setFirstName("Dummy");
		emp.setLastName("Dummy");
		emp.setEmail("abc@gmail.com");
		emp.setPhone("8523655566");
		empData.put(9999, emp);
		return emp;
	}

	@RequestMapping(value = AppConstants.GET_EMP, method = RequestMethod.GET)
	public @ResponseBody Employee getEmployee(
			@PathVariable("empId") int empId) {
		System.out.println("Start getEmployee. ID="+empId);

		return (Employee) empData.get(empId);
	}

	@RequestMapping(value = AppConstants.GET_ALL_EMP, method = RequestMethod.GET)
	public @ResponseBody List<Employee> getAllEmployees(
			@RequestParam(value = "empId", required = false) Integer empId) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("empId", empId);
		return employeeService.findAllEmployees();
	}

	@RequestMapping(value = AppConstants.CREATE_EMP, method = RequestMethod.POST)
	public @ResponseBody CreateEmployee createEmployee(@RequestBody Employee emp) {
	
		return employeeService.saveEmployee(emp);
	}

	@RequestMapping(value = AppConstants.DELETE_EMP, method = RequestMethod.DELETE)
	public @ResponseBody Employee deleteEmployee(
			@PathVariable("empId") int empId) {
		logger.info("Start delete Employee.");
		Employee emp = (Employee) empData.get(empId);
		empData.remove(empId);
		return emp;
	}
}
